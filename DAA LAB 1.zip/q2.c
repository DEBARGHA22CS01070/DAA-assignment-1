#include <stdio.h>
#include <stdlib.h>
struct btree
{
    int data;
    struct btree *left;
    struct btree *right;
};
struct stack
{
    int top;
    int capacity;
    struct tree ** array;
};
struct stack * createstack(int capacity)
{
    struct stack * s = (struct stack*)malloc(sizeof(struct stack));
    s->top = -1;
    s->capacity = capacity;
    s->array = (struct tree **)malloc(sizeof(struct tree*)*capacity);
}
int isempty(struct stack * s)
{
    return s->top == -1;
}
int isfull(struct stack * s)
{
    return s->top == s->capacity-1;
}
void push(struct stack * s,struct tree * root)
{
    s->top++;
    s->array[s->top] = root;
}
struct tree * pop(struct stack * s)
{
    struct tree * node = s->array[s->top];
    s->top--;
    return node;
}
struct tree * top(struct stack * s)
{
    return s->array[s->top];
}
struct btree *create(int data)
{
    struct btree *node = (struct btree *)malloc(sizeof(struct btree));
    node->data = data;
    node->left = NULL;
    node->right = NULL;
    return node; 
}

void inorder(struct btree *root)
{
    if (root == NULL)
        return;
    inorder(root->left);
    printf("%d ", root->data);
    inorder(root->right);
}

void preorder(struct btree *root)
{
    if (root == NULL)
        return;
    printf("%d ", root->data);
    preorder(root->left);
    preorder(root->right);
}

void postorder(struct btree *root)
{
    if (root == NULL)
        return;
    postorder(root->left);
    postorder(root->right);
    printf("%d ", root->data);
}

void search_recursive(struct btree *root, int target, int *find)
{
    if (root == NULL)
        return;
    if (root->data > target)
    {
        search_recursive(root->left, target, find);
    }
    else if (root->data < target)
    {
        search_recursive(root->right, target, find);
    }
    else if (root->data == target)
    {
        *find = 1;
    }
}
int search_iterative(struct btree * root,int target)
{
    while(root!=NULL)
    {
        if(root->data>target)
        {
            root=root->left;
        }
        else if( root->data<target)
        {
            root = root->right;
        }
        else
        {
            return 1;
        }
    }
    return 0;
}
struct btree *insert(struct btree *root, int data)
{
    if(root == NULL)
        return create(data);
    if(root->data < data)
        root->right = insert(root->right,data);
    else if(root->data > data)
        root->left = insert(root->left,data);
    return root;
}
int Successor(struct btree *root)
{
    struct btree *temp = root;
    while(temp->left != NULL){ temp = temp->left;}

    return temp->data;
}

struct btree *delete(struct btree *root, int target)
{
    if(root == NULL)
        return NULL;
    if(root->data < target)
        root->right = delete(root->right,target);
    else if(root->data > target)
        root->left = delete(root->left,target);
    else
    {
        if(root->left == NULL && root->right == NULL)
        {
            free(root);
            return NULL;
        }
        else if(root->left == NULL)
        {
            struct btree *temp = root->right;
            free(root);
            return temp;
        }
        else if(root->right == NULL)
        {
            struct btree *temp = root->left;
            free(root);
            return temp;
        }
        else
        {
            int suc =  Successor(root->right);
            root->data = suc;
            root->right = delete(root->right,suc);
        }

    }
    return root;
}

int main()
{
    struct btree *root = create(10);
    root->left = create(5);
    root->right = create(15);
    root->left->left = create(4);
    root->left->right = create(6);
    int find = 0;
    search_recursive(root, 4, &find);
    printf("%d ", find);
    printf("%d ", search_iterative(root, 16));
    printf("\n");
    root = insert(root,20);
    inorder(root);
    printf("\n");
    root = delete(root,5);
    inorder(root);
    return 0;
}
