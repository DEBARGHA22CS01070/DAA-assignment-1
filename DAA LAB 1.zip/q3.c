#include <stdio.h>
#include <stdlib.h>
struct linked 
{
    int data ;
    struct linked * next;
};
struct linked * create(int data)
{
    struct linked * node =  (struct linked *)malloc(sizeof(struct linked));
    node->data = data;
    node->next = NULL;
    return node;
}
struct linked * insert_begin(struct linked * head,int data)
{
    struct linked * node =  create(data);
    node->next = head;
    return node;
}
struct linked * insert_end(struct linked * head,int data)
{
    struct linked * node = create(data);
    struct linked * temp = head;
    while(temp->next!=NULL)
    {
        temp = temp->next;
    }
    temp->next = node;
    return head;
}
struct linked * insert_location(struct linked * head,int data,int loc)
{
    struct linked * node = create(data);
    int i=1;
    struct linked * temp = head;
    while(temp!=NULL)
    {
        if(i==loc-1)
        {
            node->next = temp->next;
            temp->next = node;
            break;
        }
        temp= temp->next;
        i++;
    }
    return head;
}
struct linked * insert_sorted(struct linked * head, int data)
{
    struct linked * node = create(data);
    struct linked * temp = head;
    struct linked * prev = NULL;

    while (temp != NULL && temp->data < data)
    {
        prev = temp;
        temp = temp->next;
    }

    if (prev == NULL)
    {
        node->next = head;
        head = node;
    }
    else
    {
        node->next = temp;
        prev->next = node;
    }

    return head;
}
struct linked * delete_first(struct linked * head)
{
    return head->next;
}
struct linked * delete_last(struct linked * head)
{
    struct linked * temp = head;
    while(temp->next->next!=NULL)
    {
        temp = temp->next;
    }
    temp->next = NULL;
    return head;
}
struct linked * delete_pos(struct linked * head,int index)
{
    int i=1;
    struct linked * temp = head;
    struct linked * prev = NULL;
    while(temp!=NULL)
    {
        if(i==index)
        {
            if(prev==NULL)
            {
                return temp->next;
            }
            prev->next = temp->next;
        }
        prev = temp;
        temp= temp->next;
        i++;
    }
    return head;
}
struct linked * delete_sorted(struct linked * head,int index)
{
    struct linked * temp = head;
    struct linked * prev = NULL;
    while(temp!=NULL)
    {
        if(temp->data==index)
        {
            if(prev==NULL)
            {
                return temp->next;
            }
            prev->next = temp->next;
        }
        prev = temp;
        temp= temp->next;
    }
    return head;
}
void frontBackSplit(struct linked *head, struct linked **front, struct linked **back)
{
    if (head== NULL || head->next == NULL)
    {
        *front = head;
        *back = NULL;
        return;
    }

    struct linked *slow = head;
    struct linked *fast = head->next;

    while (fast != NULL)
    {
        fast = fast->next;
        if (fast != NULL)
        {
            slow = slow->next;
            fast = fast->next;
        }
    }

    *front = head;
    *back = slow->next;
    slow->next = NULL;
}

int main()
{
    struct linked * head = create(10);
    head = insert_begin(head,9);
    struct linked * head2 = create(11);
    head2 = insert_end(head2,8);
    head2 = insert_end(head2,5);
    head = insert_begin(head,8);
    head = insert_end(head,11);
    head = insert_sorted(head,1);
     struct linked *front;
    struct linked *back;

    frontBackSplit(head, &front, &back);
    struct linked * temp = front;
    while(temp!=NULL)
    {
        printf("%d ",temp->data);
        temp=temp->next;
    }
    temp = back;
    printf("\n");
    while(temp!=NULL)
    {
        printf("%d ",temp->data);
        temp=temp->next;
    }
   
}
