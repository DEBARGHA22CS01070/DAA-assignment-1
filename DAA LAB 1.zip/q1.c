#include <stdio.h>
#include <stdlib.h>
struct btree
{
    int data;
    struct btree * left;
    struct btree * right;
};
struct btree * create(int data)
{
    struct btree * node = (struct btree * )malloc(sizeof(struct btree));
    node->data = data;
    node->left = NULL;
    node->right = NULL;
}
void inorder(struct btree * root)
{
    if(root==NULL) return;
    inorder(root->left);
    printf("%d ",root->data);
    inorder(root->right);
}
void preorder(struct btree * root)
{
    if(root==NULL) return;
    printf("%d ",root->data);
    preorder(root->left);
    preorder(root->right);
}
void postorder(struct btree * root)
{
    if(root==NULL) return;
    postorder(root->left);
    postorder(root->right);
    printf("%d ",root->data);
}
int main()
{
    struct btree * root = create(10);
    root->left = create(11);
    root->right = create(12);
    root->left->left = create(13);
    printf("INORDER: \n");
    inorder(root);
    printf("\n");
    printf("POSTRDER: \n");
    postorder(root);
    printf("\n");
    printf("PREORDER: \n");
    preorder(root);
}