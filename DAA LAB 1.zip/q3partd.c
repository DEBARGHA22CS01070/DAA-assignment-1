#include <stdio.h>
#include <stdlib.h>
struct linked
{
    int data;
    struct linked * next;
};
struct linked * create(int data)
{
    struct linked * node = (struct linked *)malloc(sizeof(struct linked));
    node->data= data;
    node->next = NULL;
    return node;
}
struct linked* insert(struct linked * head,int data)
{
    if(head==NULL)
    {
      struct linked * node = create(data);
      return node;
    }
    else
    {
        struct linked * temp = head;
        while(temp->next != NULL)
        {
            temp=temp->next;
        }
        struct linked* node = create(data);
        temp->next =node;
        return head;
    }
}
void partition(struct linked * start, struct linked **a, struct linked **b)
{
    struct linked * fast = start;
    struct linked * slow = start;
    
    if (fast == NULL || fast->next == NULL)
    {
        *a = start;
        *b = NULL;
        return;
    }

    while (fast->next != NULL && fast->next->next != NULL)
    {
        fast = fast->next->next;
        slow = slow->next;
    }

    *a = start;
    *b = slow->next;
    slow->next = NULL;
}

struct linked * merge(struct linked * a,struct linked* b)
{
    struct linked * res= NULL;
    if(a==NULL) return b;
    if(b==NULL) return a;
    if(a->data<b->data)
    {
        res = a;
        res->next = merge(a->next,b);
    }
    else
    {
        res = b;
        res->next = merge(a,b->next);
    }
    return res;
}

void mergesort(struct linked **head)
{
    struct linked *start = *head;
    struct linked *a = NULL;
    struct linked *b = NULL;

    if (start == NULL || start->next == NULL)
        return;

    partition(start, &a, &b);

    mergesort(&a);
    mergesort(&b);

    *head = merge(a, b);
}

int main()
{
    int A[] = {5,3,4,2,1};
    int B[] = {7,8,9,1};

    int size = sizeof(A)/sizeof(int);
    struct linked * head = NULL;
    int sizeB = sizeof(B)/sizeof(int);
    struct linked * head2 = NULL;
    for(int i=0;i<size;i++)
    {
        head = insert(head,A[i]);
    }
    for(int i=0;i<sizeB;i++)
    {
        head2 = insert(head2,B[i]);
    }
    mergesort(&head);
    mergesort(&head2);
    struct linked * node = merge(head,head2);
    while(node!=NULL)
    {
        printf("%d ",node->data);
        node=node->next;
    }
}