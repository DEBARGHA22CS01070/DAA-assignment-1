#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
void merge(char arr[], int left, int mid, int right) {
    int i, j, k;
    int len1 = mid - left + 1;
    int len2 = right - mid;

    char L[len1], R[len2];

    for (i = 0; i < len1; i++)
        L[i] = arr[left + i];
    for (j = 0; j < len2; j++)
        R[j] = arr[mid + 1 + j];

    i = 0;
    j = 0;
    k = left;

    while (i < len1 && j < len2) {
        int comp = L[i];
        int compr = R[j];
        if (L[i] >= 32 && L[i] <= 90) {
            comp = L[i] + 32;
        }
        if (R[j] >= 32 && R[j] <= 90) {
            compr = R[j] + 32;
        }
        if (comp <= compr) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < len1) {
        arr[k] = L[i];
        i++;
        k++;
    }

    while (j < len2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

void mergeSort(char arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;

        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);

        merge(arr, left, mid, right);
    }
}

int main() {
    char input[] = "DeBaRgHA";
    int n = strlen(input);
    printf("Original: %s\n", input);
    mergeSort(input, 0, n - 1);
    printf("Sorted: %s\n", input);
    return 0;
}
